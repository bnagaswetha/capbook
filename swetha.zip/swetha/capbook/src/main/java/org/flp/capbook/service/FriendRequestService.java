package org.flp.capbook.service;

import java.util.List;

import org.flp.capbook.dao.IEmailDao;
import org.flp.capbook.dao.IFriendRequestDao;
import org.flp.capbook.dao.IUserProfileDao;
import org.flp.capbook.model.Email;
import org.flp.capbook.model.Friend_request;
import org.flp.capbook.model.UserProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("FriendRequestService")
public class FriendRequestService implements IFriendRequestService{
	
	
	@Autowired
	private  IFriendRequestDao friendrequestdao;
	
	@Autowired
	private IUserProfileDao userprofiledao;
	
	@Autowired
	private IEmailDao emailDao;
/*
	@Override
	public List<String> getAllFriendRequest1(Integer receiverId) {
		// TODO Auto-generated method stub
		return friendrequestdao.getAllFriendrequest1(receiverId);
		System.out.println(request);
	}

	@Override
	public List<String> getAllFriendrequest2(Integer senderId) {
		return friendrequestdao.getAllFriendrequest1(senderId);
	}*/

	@Override
	public List<String> getAllFriendRequest1(Integer receiverId) {
		List<Integer> userIds = friendrequestdao.getAllFriendrequest1(receiverId);
		System.out.println(userIds);
		
		if(!userIds.isEmpty()){
			return userprofiledao.getEmail(userIds);
		}
		
		return null;
	}

	@Override
	public List<String> getAllFriendrequest2(Integer senderId) {
		List<Integer> userIds = friendrequestdao.getAllFriendrequest2(senderId);
		System.out.println(userIds);
		if(!userIds.isEmpty()){
			return userprofiledao.getEmail(userIds);
		}
		
		return null;
	}

	@Override
	public void sendEmail(Email email) {
		emailDao.save(email);
		
	}

	@Override
	public String getUserEmail(Integer userId) {
		
		return userprofiledao.getUserEmail(userId);
	}

}
