package org.flp.capbook.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.flp.capbook.model.Email;
import org.flp.capbook.model.Message;
import org.flp.capbook.model.Friend_request;
import org.flp.capbook.model.UserProfile;
import org.flp.capbook.service.IFriendRequestService;
import org.flp.capbook.service.IMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class FriendRequestController {
	
	@Autowired
	private IFriendRequestService FriendRequestService;
	
	@Autowired
	private IMessageService mobileService;
	
	/*@GetMapping("/request/{userId}")
	private ResponseEntity<List<String>> getFriendrequest1(@PathVariable("userId") Integer userId){
		List<String> request=FriendRequestService.getAllFriendRequest1(userId);
		System.out.println(request);
		
		return new ResponseEntity<List<String>>(request, HttpStatus.OK);
	}
	
	@GetMapping("/requests/{userId1}")
	private ResponseEntity<List<String>> getFriendrequest2(@PathVariable("userId1") Integer userId1){
		List<String> request=FriendRequestService.getAllFriendrequest2(userId1);
		
		return new ResponseEntity<List<String>>(request, HttpStatus.OK);
	}
	
	*/
	@GetMapping("/request/{userId}")
	private ResponseEntity<List<String>> getAllUserEmails(@PathVariable("userId") Integer userId){
		List<String> request=FriendRequestService.getAllFriendRequest1(userId);;
		List<String> request1=FriendRequestService.getAllFriendrequest2(userId);
		
		//System.out.println(request);
		//System.out.println(request1);
		
		if(request==null) {
			request=new ArrayList<>();
		}
		for(String user:request1) {
			request.add(user);
		}
		
		System.out.println(request);
		for(String femail:request) {
			Email email=new Email();
			email.setDate(Date.valueOf(LocalDate.now()));
			email.setFromAddress(FriendRequestService.getUserEmail(userId));
			email.setToAddress(femail);
			email.setSubject("post notification");
			email.setMessageBody("hii your friend posted one post");
			FriendRequestService.sendEmail(email);
			
		}
		
		
		return new ResponseEntity<List<String>>(request, HttpStatus.OK);
	} 
	
	@GetMapping("/mobilerequest/{userId}")
	private ResponseEntity<List<Long>> getAllUserMobile(@PathVariable("userId") Integer userId){
		List<Long> request=mobileService.getAllFriendRequest1(userId);;
		List<Long> request1=mobileService.getAllFriendrequest2(userId);
		
		//System.out.println(request);
		//System.out.println(request1);
		
		if(request==null) {
			request=new ArrayList<>();
		}
		for(Long user:request1) {
			request.add(user);
		}
		
		for(Long mobile:request) {
			Message msg=new Message();
			msg.setReceivedDate(Date.valueOf(LocalDate.now()));
			msg.setToMobileNumber(mobile);
		
			msg.setMsgBody("You have 1 new notification");
			mobileService.sendMsg(msg);
			//email.setSubject("post notification");
			//email.setMessageBody("hii your friend posted one post");
			//FriendRequestService.sendEmail(email);
			
		}
		
		
		
		return new ResponseEntity<List<Long>>(request, HttpStatus.OK);
	} 

	@GetMapping("/getMsgs/{mobileNum}")
	public ResponseEntity<List<Message>> getAllMsgsUser(
			@PathVariable("mobileNum") Long mobileNum){
		
		List<Message> messages= mobileService.getAllMessages(mobileNum);
		if(messages.isEmpty())
		{
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Message>>(messages, HttpStatus.OK);
		
	} 


}











