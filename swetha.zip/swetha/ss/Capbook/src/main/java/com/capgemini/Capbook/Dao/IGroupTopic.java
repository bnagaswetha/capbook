package com.capgemini.Capbook.Dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Capbook.model.GroupTopic;

@Repository("groupTopicDao")
@Transactional
public interface IGroupTopic extends JpaRepository<GroupTopic, Integer>{
	@Query("select g from GroupTopic g where g.groupId =:groupId")
	public List<GroupTopic> getAllTopics(@Param("groupId") Integer groupId);
	
	
	@Query("select g from GroupTopic g where g.groupId =:groupId and g.topicId=:topicId")
	public List<GroupTopic> deleteTopic(@Param("groupId") Integer groupId,@Param("topicId") Integer topicId);
	
	
	
	

}
