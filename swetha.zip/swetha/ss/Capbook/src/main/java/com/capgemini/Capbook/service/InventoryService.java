package com.capgemini.Capbook.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.Capbook.Dao.IEmailDao;
import com.capgemini.Capbook.Dao.IGroupRequestDao;
import com.capgemini.Capbook.Dao.IGroupTopic;
import com.capgemini.Capbook.Dao.IInventoryDao;
import com.capgemini.Capbook.model.Email;
import com.capgemini.Capbook.model.GroupTopic;
import com.capgemini.Capbook.model.Group_Request;
import com.capgemini.Capbook.model.Images;



@Service
public class InventoryService implements IinventoryService{
	
	@Autowired
	private IEmailDao imageDao;
	
	@Autowired
	private IInventoryDao emailDao;
	@Autowired
	private IGroupTopic groupTopicDao;
	@Autowired
	private IGroupRequestDao groupRequestDao;

	
	@Override
	public List<Email> saveEmail(Email email) {
		emailDao.save(email);
		
		return emailDao.findAll();
	}


	@Override
	public Boolean saveImage(Images image) {
		if(imageDao.save(image)!=null) {
			return true;
			}
			return false; 

	}
	@Override
	public List<GroupTopic> getAllTopics(Integer groupId) {
	
		
		return groupTopicDao.getAllTopics(groupId);
	}


	@Override
	public List<GroupTopic> deleteTopic(Integer groupId,Integer topicId) {
		//groupTopicDao.deleteById(topicId);
		//return groupTopicDao.findAll();
		
		groupTopicDao.deleteById(topicId);
		return groupTopicDao.getAllTopics(groupId);
	}


	@Override
	public List<Email> getAllEmails() {
		
		return emailDao.findAll();
	}


	@Override
	public List<Group_Request> getAllGroupMembers(Integer groupId) {
		
		return groupRequestDao.getAllGroupMembers(groupId);
	}


	@Override
	public List<Group_Request> deleteGroupMember(Integer groupId, Integer userId) {
		 List<Group_Request>groups=groupRequestDao.deleteGroupMember(groupId, userId);

		 for( Group_Request group: groups)
		 {
			 groupRequestDao.delete(group);
			 
		 }
		 
		 return groupRequestDao.getAllGroupMembers(groupId);
	}


	@Override
	public List<Email> getAllEmailsOfUser(String emailId) {
		
		return emailDao.getAllEmailsOfUser(emailId);
	}



} 
 
