package com.capgemini.Capbook.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class GroupTopic {
	@Id
	@GeneratedValue
	private Integer topicId;
	private Integer userId;
	private String topicDescription;
	private Integer groupCommentId;
	private Integer groupId;
	public GroupTopic() {
		super();
	}
	public GroupTopic(Integer topicId, Integer userId, String topicDescription, Integer groupCommentId,
			Integer groupId) {
		super();
		this.topicId = topicId;
		this.userId = userId;
		this.topicDescription = topicDescription;
		this.groupCommentId = groupCommentId;
		this.groupId = groupId;
	}
	public Integer getTopicId() {
		return topicId;
	}
	public void setTopicId(Integer topicId) {
		this.topicId = topicId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getTopicDescription() {
		return topicDescription;
	}
	public void setTopicDescription(String topicDescription) {
		this.topicDescription = topicDescription;
	}
	public Integer getGroupCommentId() {
		return groupCommentId;
	}
	public void setGroupCommentId(Integer groupCommentId) {
		this.groupCommentId = groupCommentId;
	}
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	@Override
	public String toString() {
		return "GroupTopic [topicId=" + topicId + ", userId=" + userId + ", topicDescription=" + topicDescription
				+ ", groupCommentId=" + groupCommentId + ", groupId=" + groupId + "]";
	}
	
	
	

}
