package com.capgemini.Capbook.service;

import java.util.List;

import com.capgemini.Capbook.model.Email;
import com.capgemini.Capbook.model.GroupTopic;
import com.capgemini.Capbook.model.Group_Request;
import com.capgemini.Capbook.model.Images;



public interface IinventoryService {

	

	

	List<Email> saveEmail(Email email);

	Boolean saveImage(Images image);

	List<GroupTopic> getAllTopics(Integer groupId);

	

	List<GroupTopic> deleteTopic(Integer groupId, Integer topicId);

	List<Email> getAllEmails();
	List<Group_Request> getAllGroupMembers(Integer groupId);
	
	List<Group_Request> deleteGroupMember(Integer groupId,Integer userId);

	List<Email> getAllEmailsOfUser(String emailId);

	

	

}
