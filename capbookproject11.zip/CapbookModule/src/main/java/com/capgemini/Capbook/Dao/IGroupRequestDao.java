package com.capgemini.Capbook.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Capbook.model.GroupTopic;
import com.capgemini.Capbook.model.Group_Request;



@Repository("groupRequestDao")
@Transactional
public interface IGroupRequestDao extends JpaRepository<Group_Request, Integer>{
	@Query("select g from Group_Request g where g.groupId =:groupId and g.status='Approved'")
	public List<Group_Request> getAllGroupMembers(@Param("groupId") Integer groupId);
	
	@Query("from Group_Request  where group_id =:groupId and user_id=:userId")
	public  List<Group_Request> deleteGroupMember(@Param("groupId") Integer groupId,@Param("userId") Integer userId);

}
