package com.capgemini.Capbook.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Capbook.model.Email;



@Repository("emailDao")
@Transactional
public interface IInventoryDao extends JpaRepository<Email, Integer>{

	@Query("select e from Email e where e.toAddress =:emailId")
	public List<Email> getAllEmailsOfUser(@Param("emailId") String  emailId);

}
