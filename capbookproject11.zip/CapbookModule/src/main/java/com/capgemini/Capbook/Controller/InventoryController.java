package com.capgemini.Capbook.Controller;


import java.io.File;
import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.Capbook.model.Email;
import com.capgemini.Capbook.model.GroupTopic;
import com.capgemini.Capbook.model.Group_Request;
import com.capgemini.Capbook.model.Images;
import com.capgemini.Capbook.service.IinventoryService;





@RestController
@CrossOrigin("*")
public class InventoryController {
	@Autowired
	private IinventoryService inventoryService;
	@PostMapping("/sendEmail")
	public ResponseEntity<List<Email>> saveEmail(@RequestBody Email email){
		
		email.setDate(Date.valueOf(LocalDate.now()));
		//email
		
		
		
		
		List<Email> emails= inventoryService.saveEmail(email);
		
		if(emails.isEmpty())
		{
			return new ResponseEntity("Sorry! emails not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Email>>(emails, HttpStatus.OK);
		
	}
	@GetMapping("/getEmails")
	public ResponseEntity<List<Email>> getAllEmails(){
		
		List<Email> emails= inventoryService.getAllEmails();
		if(emails.isEmpty())
		{
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Email>>(emails, HttpStatus.OK);
		
	}
	@GetMapping("/getEmails/{emailId}")
	public ResponseEntity<List<Email>> getAllEmailsOfUser(
			@PathVariable("emailId")String emailId){
		
		List<Email> emails= inventoryService.getAllEmailsOfUser(emailId);
		if(emails.isEmpty())
		{
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Email>>(emails, HttpStatus.OK);
		
	}
	
	@PostMapping("/saveImage")
	public boolean saveImage(@RequestBody Images image) {
		
		try{
    		
	    	   File afile =image.getFile();
	    		
	    	   if(afile.renameTo(new File("D:\\project\\Capbook\\src\\main\\resources\\static\\Posts\\" + afile.getName()))){
	    		System.out.println("File is moved successful!");
	    	   }else{
	    		System.out.println("File is failed to move!");
	    	   }
	    	   image.setImageUrl("D:\\project\\Capbook\\src\\main\\resources\\static\\Posts\\" + afile.getName());
	    	   
	    	    
	    	}catch(Exception e){
	    		e.printStackTrace();
	    	}
		
		
		
		return inventoryService.saveImage(image);	
	}
	
	
	@GetMapping("/groupTopics/{groupId}")
	public ResponseEntity<List<GroupTopic>> getAllTopics(
			@PathVariable("groupId")Integer groupId){
		
		List<GroupTopic> topics= inventoryService.getAllTopics(groupId);
		if(topics.isEmpty())
		{
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<GroupTopic>>(topics, HttpStatus.OK);
		
	}
	@DeleteMapping("/deleteTopics/{groupId}/{topicId}")
	public ResponseEntity<List<GroupTopic>> deleteTopic(
			@PathVariable("groupId")Integer groupId,
			@PathVariable("topicId")Integer topicId){
		List<GroupTopic> topics= inventoryService.deleteTopic(groupId, topicId);
		if(topics.isEmpty() || topics==null) {
			return new ResponseEntity("Sorry! ProductsId not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<GroupTopic>>(topics, HttpStatus.OK);
	} 
	
	@GetMapping("/getAllGroupMembers/{groupId}")
	public ResponseEntity<List<Group_Request>> getAllGroupMembers(
			@PathVariable("groupId")Integer groupId){
		
		List<Group_Request> groupMembers= inventoryService.getAllGroupMembers(groupId);
		if(groupMembers.isEmpty())
		{
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Group_Request>>(groupMembers, HttpStatus.OK);
		
	}
	@DeleteMapping("/deleteGroupMember/{groupId}/{userId}")
	public ResponseEntity<List<Group_Request>> deleteGroupMember(
			@PathVariable("groupId")Integer groupId,
			@PathVariable("userId")Integer userId){
		List<Group_Request> groupMembers= inventoryService.deleteGroupMember(groupId, userId);
		if(groupMembers.isEmpty())
		{
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Group_Request>>(groupMembers, HttpStatus.OK);
	}
	


} 
