import { Injectable } from "@angular/core";
import { ITopic } from "../../api/topics/topics";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";
import {tap} from "rxjs/internal/operators";
import {catchError} from "rxjs/internal/operators";
import { GroupsService } from '../groups/groups.service';


@Injectable()
export class TopicService{
    private _topicUrl='http://localhost:8087/api/groupTopics';
    private _topicDeleteUrl='http://localhost:8087/api/deleteTopics';
    public  topics:ITopic[]=[];
    
    constructor(private _http:HttpClient){

    }
    getTopics():Observable<ITopic[]>{
        this._topicUrl=this._topicUrl+"/"+GroupsService.group.groupId;
        return  this._http.get<ITopic[]>(this._topicUrl).pipe(
        tap(data =>console.log('All:'+ JSON.stringify(data))))
        .pipe(catchError(this.handleError))
    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    deleteTopics(groupId,topicId):Observable<ITopic[]>{
        this._topicDeleteUrl=this._topicDeleteUrl+'/'+groupId+'/'+topicId;

        return  this._http.delete<ITopic[]>(this._topicDeleteUrl).pipe(
        tap(data =>console.log('All:'+ JSON.stringify(data))))
        .pipe(catchError(this.handleError))
    }
    
}