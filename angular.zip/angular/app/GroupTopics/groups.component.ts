import { IGroups } from "../../api/groups/groups";
import { Component, OnInit } from "@angular/core";
import { GroupsService } from "../../api/groups/groups.service";
import { ITopic } from '../../api/topics/topics';
import { TopicService } from '../../api/topics/topics.service';


@Component({
    //selector:'pm-topic',
     templateUrl:'./groups.component.html',
    styles:['thead{color:#337AB7;}']
     
 })
 export class GroupComponent implements OnInit{
     pageTitle:string='groups';
     groups:IGroups[]=[];
     topic:ITopic[]=[];
     errorMessage:string;
     constructor(private _groupService:GroupsService,topicService:TopicService)
     {
          
     }
    
 
  ngOnInit():void{
      // console.log('In OnInit')
      this._groupService.getGroups().subscribe(groups=> {
          this.groups=groups;
         // this.filteredCustomers=this.customers;
         
          
      },
      error=>this.errorMessage=<any>error
      );
     
      
  }
  private showTopics(groups:IGroups){

    GroupsService.group=groups;
   


  }
  
 

}
 

 