import { Component } from '@angular/core';
import {TopicService} from '../api/topics/topics.service'
import { GroupsService } from '../api/groups/groups.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  //templateUrl:'./GroupTopics/topic.component.html',
  styleUrls: ['./app.component.styl'],
 providers:[TopicService,GroupsService] 

})
export class AppComponent {
  title = 'deleteTopic';
}
