import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TopicComponent } from './GroupTopics/topic.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { TopicService } from '../api/topics/topics.service';
import { ButtonComponent } from './button/button.component';
import {RouterModule,Routes} from '@angular/router';
import { GroupComponent } from './GroupTopics/groups.component';
import { GroupsService } from '../api/groups/groups.service';

const apploads:Routes=[
  // {path: 'groups',component:TopicComponent }
     {path: 'groups',component:GroupComponent },
     {path: 'groups/topics',component:TopicComponent }
];

@NgModule({
  declarations: [
    AppComponent,TopicComponent, ButtonComponent,GroupComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(apploads)
  ],
  providers: [TopicService,GroupsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
