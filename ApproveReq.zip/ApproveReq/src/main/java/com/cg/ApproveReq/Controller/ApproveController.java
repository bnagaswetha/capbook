package com.cg.ApproveReq.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ApproveReq.Model.Approve;
import com.cg.ApproveReq.Service.IApproveService;

@RestController
@RequestMapping("/approve")
@CrossOrigin("*")
public class ApproveController {
	
	
	@Autowired
	private IApproveService approveService;
	
	@GetMapping("/getApproval")
	public ResponseEntity<List<Approve>> getReqApproval(){
		List<Approve> approve= approveService.getApprovingDetails();
		System.out.println(approve);
		if(approve.isEmpty())
			return new ResponseEntity(
					"Sorry! no requests", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Approve>>(approve, HttpStatus.OK);
	}

	@PutMapping("/status")
	public ResponseEntity<List<Approve>> getStatus(@RequestBody Approve approve){
		 //approve=approveService.getApproveById(groupReqId);
		//System.out.println(approve);
		List<Approve> approves= approveService.updateStatus(approve);
		if(approves.isEmpty())
			return new ResponseEntity(
					"Sorry! no requests", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Approve>>(approves, HttpStatus.OK);
	}

	
}
