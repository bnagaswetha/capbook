package com.cg.ApproveReq.Dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.ApproveReq.Model.UserProfile;

@Repository("userDao")
@Transactional
public interface IUserDao extends  JpaRepository<UserProfile,Integer> {

	
	@Query("select u.userName from UserProfile u where u.userId = :id")
	String getUserName(@Param("id")Integer userId);
	
	
	

}
