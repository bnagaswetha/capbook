package com.cg.ApproveReq.Service;

import java.util.List;


import com.cg.ApproveReq.Model.Approve;

public interface IApproveService {
	
	public List<Approve> getApprovingDetails();
	
	public List<Approve> updateStatus(Approve approve);

	public Approve getApproveById(Integer groupReqId);

}
