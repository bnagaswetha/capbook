package com.cg.ApproveReq.Dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.ApproveReq.Model.Approve;


@Repository("approveDao")
@Transactional
public interface IApprovedao extends JpaRepository<Approve,Integer> {
	
	
	@Query(" from Approve where status='Pending'")
	public List<Approve> getApprovingDetails();
/*	
	@Modifying
	@Query( "update Approve  set status = 'Approved'  WHERE groupReqId = :groupRequestId")
	public List<String> updateStatus(@Param("groupRequestId") Integer groupRequestId);*/
	

	
	
	
}
