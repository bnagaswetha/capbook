package com.cg.ApproveReq.Model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name="GROUP_REQUEST")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Approve {

	@Id
	@GeneratedValue
	private Integer groupReqId;
	private Integer groupId;
	private Integer userId;
	private String status;
	@Transient
	private String userName;
	
	public Approve() {
		super();
	}

	public Approve(Integer groupReqId, Integer groupId, Integer userId, String status, String userName) {
		super();
		this.groupReqId = groupReqId;
		this.groupId = groupId;
		this.userId = userId;
		this.status = status;
		this.userName = userName;
	}

	public Integer getGroupReqId() {
		return groupReqId;
	}

	public void setGroupReqId(Integer groupReqId) {
		this.groupReqId = groupReqId;
	}

	public Integer getGroupId() {
		return groupId;
	}

	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Override
	public String toString() {
		return "Approve [groupReqId=" + groupReqId + ", groupId=" + groupId + ", userId=" + userId + ", status="
				+ status + ", userName=" + userName + "]";
	}
	
}
