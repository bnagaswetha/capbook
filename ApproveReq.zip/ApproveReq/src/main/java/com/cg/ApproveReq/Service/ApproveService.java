package com.cg.ApproveReq.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ApproveReq.Dao.IApprovedao;
import com.cg.ApproveReq.Dao.IUserDao;
import com.cg.ApproveReq.Model.Approve;

@Service("approveService")
public class ApproveService implements IApproveService{
	
	@Autowired
	private IApprovedao approveDao;
 
	@Autowired
	private IUserDao userDao;
	
	@Override
	public List<Approve> getApprovingDetails() {
		
		List<Approve> approve=approveDao.getApprovingDetails();
		for(Approve app:approve) {
			System.out.println("for each loop");
			app.setUserName(userDao.getUserName(app.getUserId()));
			System.out.println(app);
		}
		
		return approve ;
	}

	@Override
	public List<Approve> updateStatus(Approve approve) {
		approveDao.save(approve);
		return approveDao.findAll();
	}

	@Override
	public Approve getApproveById(Integer groupReqId) {
		
		return approveDao.getOne(groupReqId) ;
	}
	
	

}
