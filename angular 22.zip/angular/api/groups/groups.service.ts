import { Injectable } from "@angular/core";
import { IGroups } from "../../api/groups/groups";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";
import {tap} from "rxjs/internal/operators";
import {catchError} from "rxjs/internal/operators";
import { ITopic } from '../topics/topics';


@Injectable()
export class GroupsService{
    private _groupUrl='http://localhost:8087/api/getGroups/101';
    public static group:IGroups;
    constructor(private _http:HttpClient){

    }
    getGroups():Observable<IGroups[]>{
        return  this._http.get<IGroups[]>(this._groupUrl).pipe(
        tap(data =>console.log('All:'+ JSON.stringify(data))))
        .pipe(catchError(this.handleError))
    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    getTopics():Observable<ITopic[]>{
        return  this._http.get<ITopic[]>(this._groupUrl).pipe(
        tap(data =>console.log('All:'+ JSON.stringify(data))))
        .pipe(catchError(this.handleError))
    }
    
    
}