import { Component } from '@angular/core';
import { GRequestsService } from '../api/grouprequests/grouprequests.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.styl'],
  providers:[GRequestsService]
})
export class AppComponent {
  title = 'deleteMember';
}
