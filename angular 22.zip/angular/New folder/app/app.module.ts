import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GRequestsService } from '../api/grouprequests/grouprequests.service';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { GroupRequestComponent } from './GroupRequests/grouprequest.component';

@NgModule({
  declarations: [
    AppComponent,
    GroupRequestComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [GRequestsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
