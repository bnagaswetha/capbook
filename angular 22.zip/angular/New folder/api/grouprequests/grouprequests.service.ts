import { Injectable } from "@angular/core";
import { IGrequests } from "../../api/grouprequests/grequests";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";
import {tap} from "rxjs/internal/operators";
import {catchError} from "rxjs/internal/operators";


@Injectable()
export class GRequestsService{
    private _groupUrl='http://localhost:8085/getAllGroupMembers/301';
    private _deleteMemberUrl='http://localhost:8085/deleteGroupMember';
    constructor(private _http:HttpClient){

    }
    getGroupMembers():Observable<IGrequests[]>{
        return  this._http.get<IGrequests[]>(this._groupUrl).pipe(
        tap(data =>console.log('All:'+ JSON.stringify(data))))
        .pipe(catchError(this.handleError))
    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    deleteGroupMember(groupId,userId):Observable<IGrequests[]>{
        this._deleteMemberUrl=this._deleteMemberUrl+'/'+groupId+'/'+userId;

        return  this._http.delete<IGrequests[]>(this._deleteMemberUrl).pipe(
        tap(data =>console.log('All:'+ JSON.stringify(data))))
        .pipe(catchError(this.handleError))
    }
    
}