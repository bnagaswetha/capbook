export interface IGrequests{
    gRequestId:number;
    groupId:number;
    status:string;
    userId:number;
   
   
}