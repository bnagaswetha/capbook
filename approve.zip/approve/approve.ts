export class Approve{

     groupReqId:number;
	 groupId:number;
	 userId:number;
	 status:String;
	 userName:string;
}