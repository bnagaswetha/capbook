package org.flp.capbook.service;

import java.util.List;

import org.flp.capbook.dao.IGroupRequestDao;
import org.flp.capbook.dao.IGroupTopic;
import org.flp.capbook.dao.IGroupsDao;
import org.flp.capbook.model.Group_Request;
import org.flp.capbook.model.Group_Topic;
import org.flp.capbook.model.Groups;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;




@Service
public class GroupServiceImpl implements IGroupService{
	
	@Autowired
	private IGroupsDao groupsDao;
	
	@Autowired
	private IGroupTopic groupTopicDao;
	
	@Autowired
	private IGroupRequestDao groupRequestDao;
	

	
	@Override
	public List<Groups> getAllGroups(Integer userId) {
		
		//String groupAdmin=groupsDao.getGroupAdmin(userId);
		
		return groupsDao.getAllGroups(userId);
	}


	@Override
	public List<Group_Topic> getAllTopics(Integer groupId) {
		return groupTopicDao.getAllTopics(groupId);
		
	}


	@Override
	public List<Group_Topic> deleteTopic(Integer groupId, Integer topicId) {
		System.out.println("in delete service");
		groupTopicDao.deleteById(topicId);
		return groupTopicDao.getAllTopics(groupId);
	}


	@Override
	public List<Group_Request> getAllGroupMembers(Integer groupId) {
		return groupRequestDao.getAllGroupMembers(groupId);
	}

}
