package org.flp.capbook.service;

import java.util.List;

import org.flp.capbook.dao.ILoginDao;
import org.flp.capbook.model.Login;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("LoginService")
public class LoginService implements ILoginService {
	
	@Autowired
	private ILoginDao logindao;

	@Override
	public List<Login> getAllLogins() {
	
		return logindao.findAll();
	}


	public List<Login> saveLogin(Login login) {
		
		logindao.save(login);
		return logindao.findAll();
	}

	
	
	
	
}
