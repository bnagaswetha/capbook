package org.flp.capbook.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.flp.capbook.model.Email;
import org.flp.capbook.model.Message;
import org.flp.capbook.model.Friend_request;
import org.flp.capbook.model.Group_Request;
import org.flp.capbook.model.Group_Topic;
import org.flp.capbook.model.Groups;
import org.flp.capbook.model.UserProfile;
import org.flp.capbook.service.IEmailService;
import org.flp.capbook.service.IFriendRequestService;
import org.flp.capbook.service.IGroupService;
import org.flp.capbook.service.IMessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;





@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class FriendRequestController {

	@Autowired
	private IFriendRequestService FriendRequestService;

	@Autowired
	private IMessageService mobileService;
	
	@Autowired
	private IEmailService emailService;
	
	@Autowired
	private IGroupService groupService;


	@GetMapping("/sendEmail/{userId}")
	private ResponseEntity<List<String>> getAllUserEmails(@PathVariable("userId") Integer userId){
		List<String> request=FriendRequestService.getAllFriendRequest1(userId);;
		List<String> request1=FriendRequestService.getAllFriendrequest2(userId);

		//System.out.println(request);
		//System.out.println(request1);

		if(request==null) {
			request=new ArrayList<>();
		}

		if(request1==null) {
			request1=new ArrayList<>();
		}else {

			for(String user:request1) {
				request.add(user);
			}
		}

		System.out.println(request);
		for(String femail:request) {
			Email email=new Email();
			email.setDate(Date.valueOf(LocalDate.now()));
			email.setFromAddress(FriendRequestService.getUserEmail(userId));
			email.setToAddress(femail);
			email.setSubject("post notification");
			email.setMessageBody("hii your friend posted one post");
			FriendRequestService.sendEmail(email);

		}


		return new ResponseEntity<List<String>>(request, HttpStatus.OK);
	} 
	
	@GetMapping("/getEmails/{userId}")
	public ResponseEntity<List<Email>> getAllEmailsUser(
			@PathVariable("userId") Integer userId){
		String email=emailService.getUserEmail(userId);

		List<Email> emails= emailService.getAllEmailsOfUser(email);
		if(emails.isEmpty())
		{
			return new ResponseEntity("Sorry! No Messages available!", 
					HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Email>>(emails, HttpStatus.OK);

	} 
	

	@GetMapping("/sendMsg/{userId}")
	private ResponseEntity<List<Long>> getAllUserMobile(@PathVariable("userId") Integer userId){
		List<Long> request=mobileService.getAllFriendRequest1(userId);;
		List<Long> request1=mobileService.getAllFriendrequest2(userId);
		String userName = mobileService.getUserName(userId);

		//System.out.println(request);
		//System.out.println(request1);

		if(request==null) {
			request=new ArrayList<>();
		}
		for(Long user:request1) {
			request.add(user);
		}

		for(Long mobile:request) {
			Message msg=new Message();
			msg.setReceivedDate(Date.valueOf(LocalDate.now()));
			msg.setUserName(userName);
			msg.setMobileNumber(mobile);

			msg.setMsgBody("You have 1 new notification");
			mobileService.sendMsg(msg);


		}



		return new ResponseEntity<List<Long>>(request, HttpStatus.OK);
	} 

	@GetMapping("/getMsgs/{userId}")
	public ResponseEntity<List<Message>> getAllMsgsUser(
			@PathVariable("userId") Integer userId){
		Long mobileNum=mobileService.getUserMobileNum(userId);

		List<Message> messages= mobileService.getAllMessages(mobileNum);
		if(messages.isEmpty())
		{
			return new ResponseEntity("Sorry! No Messages available!", 
					HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Message>>(messages, HttpStatus.OK);

	} 
	@GetMapping("/getGroups/{userId}")
	public ResponseEntity<List<Groups>> getAllGroups(
			@PathVariable("userId") Integer userId){
		

		List<Groups> groups= groupService.getAllGroups(userId);
		if(groups.isEmpty())
		{
			return new ResponseEntity("Sorry! No groups  available!", 
					HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Groups>>(groups, HttpStatus.OK);

	} 
	@GetMapping("/groupTopics/{groupId}")
	public ResponseEntity<List<Group_Topic>> getAllTopics(
			@PathVariable("groupId")Integer groupId){
		
		List<Group_Topic> topics= groupService.getAllTopics(groupId);
		if(topics.isEmpty())
		{
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Group_Topic>>(topics, HttpStatus.OK);
		
	}
	@DeleteMapping("/deleteTopics/{groupId}/{topicId}")
	public ResponseEntity<List<Group_Topic>> deleteTopic(
			@PathVariable("groupId")Integer groupId,
			@PathVariable("topicId")Integer topicId){
		List<Group_Topic> topics= groupService.deleteTopic(groupId, topicId);
		if(topics.isEmpty() || topics==null) {
			return new ResponseEntity("Sorry! topics not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Group_Topic>>(topics, HttpStatus.OK);
	} 
	
	@GetMapping("/getAllGroupMembers/{groupId}")
	public ResponseEntity<List<Group_Request>> getAllGroupMembers(
			@PathVariable("groupId")Integer groupId){
		
		List<Group_Request> groupMembers= groupService.getAllGroupMembers(groupId);
		if(groupMembers.isEmpty())
		{
			return new ResponseEntity("Sorry! Products not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<Group_Request>>(groupMembers, HttpStatus.OK);
		
	}
	
	


}











