package org.flp.capbook.dao;


import java.util.List;


import org.flp.capbook.model.Groups;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("groupsDao")
@Transactional
public interface IGroupsDao extends JpaRepository<Groups,Integer>{
	
//	@Query("select g. from Group g where g.groupAdmin =:userId")
//	public   getGroupAdmin(@Param("userId") Integer  userId);

	
	@Query("select g from Groups g where g.groupAdmin =:userId")
	public List<Groups> getAllGroups(@Param("userId") Integer userId);

}
