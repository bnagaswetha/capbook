package org.flp.capbook.dao;

import java.util.List;

import org.flp.capbook.model.Group_Topic;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("groupTopicDao")
@Transactional
public interface IGroupTopic extends JpaRepository<Group_Topic, Integer>{
	@Query("select g from Group_Topic g where g.group_id =:groupId")
	public List<Group_Topic> getAllTopics(@Param("groupId") Integer groupId);
	
	
	@Query("select g from Group_Topic g where g.group_id =:groupId and g.topic_id=:topicId")
	public List<Group_Topic> deleteTopic(@Param("groupId") Integer groupId,@Param("topicId") Integer topicId);
	
	

}
