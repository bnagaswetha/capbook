package org.flp.capbook.dao;

import java.util.List;


import org.flp.capbook.model.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("userprofiledao")
@Transactional

public interface IUserProfileDao extends JpaRepository<UserProfile,String> {

	@Query("select u.email from UserProfile u where u.userId in :userId")
	List<String> getEmail(@Param("userId")List<Integer> userId);
	
	
	@Query("select u.mobileNo from UserProfile u where u.userId in :userId")
	List<Long> getMobileNumber(@Param("userId")List<Integer> userId);
	
	@Query("select u.email from UserProfile u where u.userId=:userId")
	String getUserEmail(@Param("userId") Integer userId);
	
	@Query("select u.mobileNo from UserProfile u where u.userId in :userId")
	Long getUserMobileNum(@Param("userId") Integer userId);
	
	
	
	@Query("select u.userName from UserProfile u where u.userId=:userId")
	String getUserName(@Param("userId") Integer userId);
	
	
	
	
}
