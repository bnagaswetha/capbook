package org.flp.capbook.dao;

import java.sql.Date;
import java.util.List;

import org.flp.capbook.model.Friend_request;
import org.flp.capbook.model.UserProfile;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("friendrequestdao")
@Transactional

public interface IFriendRequestDao extends JpaRepository<Friend_request,Integer>{

//	@Query("select u.email from UserProfile u where u.userId in (select f.senderId from Friend_request f where f.receiverId=:id and f.status ='accept')")
	@Query(value="select f.sender_id from friend_request f where f.receiver_id=:id and f.status ='accept'",nativeQuery=true)
	public List<Integer> getAllFriendrequest1(@Param("id")Integer userId);
	
	
//	@Query("select u.email from UserProfile u where u.userId in (select f.receiverId from Friend_request f where f.senderId=:id  and f.status ='accept')")
	@Query("select f.receiverId from Friend_request f where f.senderId=:id and f.status ='accept'")
	public List<Integer> getAllFriendrequest2(@Param("id")Integer userId);
	
	
	
	
	
}



