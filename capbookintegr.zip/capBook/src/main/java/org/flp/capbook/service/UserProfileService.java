package org.flp.capbook.service;

import java.util.List;

import org.flp.capbook.dao.IUserProfileDao;
import org.flp.capbook.model.UserProfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("UserProfileService")
public class UserProfileService implements IUserProfileService {
	
	@Autowired
	private IUserProfileDao userprofiledao;

	@Override
	public List<UserProfile> getAllUserprofiles() {
	
		return userprofiledao.findAll();
	}

}
